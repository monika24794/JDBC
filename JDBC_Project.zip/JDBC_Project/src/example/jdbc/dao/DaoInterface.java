package example.jdbc.dao;

import java.util.Collection;
//this ineterface provide basic template for Dao pattern
//its implementaion class desides th actual entity type 
//and the id type.
public interface DaoInterface<T ,K> 
{
	
	Collection<T> retriveAll();

}
//customer id:int --->integer----->  CustomerDao <Customer ,integer>
