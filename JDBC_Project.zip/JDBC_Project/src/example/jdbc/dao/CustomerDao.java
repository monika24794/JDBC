package example.jdbc.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import com.mysql.cj.jdbc.JdbcConnection;

import example.jdbc.entity.Customer;
import example.jdbc.util.JdbcUtils;

public class CustomerDao implements DaoInterface<Customer, Integer>
{

	@Override
	public Collection<Customer> retriveAll() {
		//creating  an empty collection of customers
		Collection<Customer> allCustomers=new ArrayList<>();
		
		String sqlQuery=" select cname,address,custid from customer1";
		try( Connection dbConnection=JdbcUtils.buildConnection();
				Statement stmt= dbConnection.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuery) 
	){
			 while (rs.next()) {
			
				String name=rs.getString(1);
				String Address=rs.getString(2);
				 int id=rs.getInt(3);
				Customer currentCustomer=new Customer(id,name,Address);
				allCustomers.add(currentCustomer);
		}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return allCustomers;
	}

}
